
export type UserRole = 'client' | 'admin'
export type User = {
  id: string
  email: string
  name: string
  role: UserRole
  verified: boolean
}

export type Product = {
  termMonths: number
  rate: number
  minDeposit: number
  maxDeposit: number
  compounding: boolean
}
