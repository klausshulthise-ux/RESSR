
import React from 'react'

export default function FAQ(){
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Häufige Fragen (FAQ)</h1>
      <h2>Was ist Festgeld?</h2>
      <p>Festgeld ist eine Geldanlage mit fester Laufzeit und festem Zinssatz. Während der Laufzeit ist das Geld in der Regel nicht verfügbar. Am Ende erhältst du dein Kapital plus Zinsen zurück.</p>
      <h2>Kann ich vorzeitig kündigen?</h2>
      <p>Eine vorzeitige Kündigung ist grundsätzlich nicht vorgesehen. In besonderen Härtefällen kann es Ausnahmen geben; die Regelungen findest du in den AGB.</p>
      <h2>Wie läuft die Kontoeröffnung?</h2>
      <p>Du wählst ein Produkt, füllst den Antrag aus und bestätigst deine Identität per VideoIdent, eID oder PostIdent. Danach leistest du die Einzahlung über dein Referenzkonto.</p>
      <h2>Wie werden Zinsen ausgezahlt?</h2>
      <p>Standardmäßig am Laufzeitende. Bei Laufzeiten ab 36 Monaten kann jährliche Zinszahlung angeboten werden; Details je Produkt.</p>
    </div>
  )
}
