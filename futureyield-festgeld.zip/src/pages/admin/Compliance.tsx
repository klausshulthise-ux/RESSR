
import React from 'react'
export default function AdminCompliance(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Compliance</h3>
      <p>AML/PEP/US-Person-Prüfungen, Monitoring und Protokollierung. (Demo – später KYC/AML-Provider anbinden)</p>
    </div>
  )
}
