
import React from 'react'
export default function AdminCustomers(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Kunden</h3>
      <p>Verwaltung von Kundenstammdaten, Rollen und Status. (Demo-Inhalte)</p>
    </div>
  )
}
