
import React from 'react'
import { Routes, Route, NavLink } from 'react-router-dom'
import AdminOverview from './Overview'
import AdminCustomers from './Customers'
import AdminApps from './Applications'
import AdminCompliance from './Compliance'

export default function Admin(){
  return (
    <div className="container py-8">
      <h1 className="text-2xl font-semibold mb-6">Admin – Control Center</h1>
      <div className="grid md:grid-cols-4 gap-6">
        <aside className="card p-4">
          <nav className="flex flex-col gap-2 text-sm">
            <NavLink to="" end className="hover:underline">Übersicht</NavLink>
            <NavLink to="kunden" className="hover:underline">Kunden</NavLink>
            <NavLink to="antraege" className="hover:underline">Anträge</NavLink>
            <NavLink to="compliance" className="hover:underline">Compliance</NavLink>
          </nav>
        </aside>
        <section className="md:col-span-3">
          <div className="card p-4">
            <Routes>
              <Route index element={<AdminOverview/>} />
              <Route path="kunden" element={<AdminCustomers/>} />
              <Route path="antraege" element={<AdminApps/>} />
              <Route path="compliance" element={<AdminCompliance/>} />
            </Routes>
          </div>
        </section>
      </div>
    </div>
  )
}
