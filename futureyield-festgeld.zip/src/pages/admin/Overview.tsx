
import React from 'react'
export default function AdminOverview(){
  return (
    <div className="grid md:grid-cols-3 gap-4">
      <Info label="Aktive Kunden" value="128" />
      <Info label="Offene Anträge" value="12" />
      <Info label="KYC in Prüfung" value="5" />
    </div>
  )
}
function Info({label, value}:{label:string; value:string}){
  return <div className="bg-white border rounded-3xl p-4"><div className="text-xs text-gray-500">{label}</div><div className="text-lg font-semibold">{value}</div></div>
}
