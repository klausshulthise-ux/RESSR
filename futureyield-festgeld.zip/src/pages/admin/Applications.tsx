
import React from 'react'
export default function AdminApps(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Anträge</h3>
      <p>Liste aller Anträge, inkl. Statuswechsel (eingereicht → KYC → genehmigt/abgelehnt). (Demo)</p>
    </div>
  )
}
