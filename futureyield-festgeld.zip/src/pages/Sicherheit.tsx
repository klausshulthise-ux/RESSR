
import React from 'react'

export default function Sicherheit(){
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Einlagensicherung & Sicherheit</h1>
      <p>Die Sicherheit deiner Einlagen hat höchste Priorität. FutureYield unterliegt den europarechtlichen Vorgaben zur Einlagensicherung. Pro Kunde und Bank sind Einlagen bis zu 100.000 € gesetzlich geschützt.</p>
      <h2>Wie funktioniert die Einlagensicherung?</h2>
      <ul>
        <li><strong>Schutzumfang:</strong> Sicht-, Termin- und Spareinlagen sind abgedeckt.</li>
        <li><strong>Höhe:</strong> 100.000 € pro Kunde und Bank. Bei Gemeinschaftskonten je Kontoinhaber.</li>
        <li><strong>Rechtsgrundlage:</strong> EU-Richtlinie 2014/49/EU.</li>
      </ul>
      <h2>Weitere Schutzmechanismen</h2>
      <ul>
        <li>Trennung von Kundengeldern und Bankvermögen.</li>
        <li>IT-Sicherheitsstandards, Verschlüsselung und starke Authentisierung.</li>
        <li>Regelmäßige Audits und Compliance-Reviews.</li>
      </ul>
    </div>
  )
}
