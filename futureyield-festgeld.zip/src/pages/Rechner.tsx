
import React, { useMemo, useState } from 'react'
import { PRODUCTS } from '../data.products'
import { calcMaturity } from '../utils.logic'

export default function Rechner() {
  const [amount, setAmount] = useState(10000)
  const [term, setTerm] = useState(PRODUCTS[1].termMonths)
  const product = PRODUCTS.find(p=>p.termMonths===term)!
  const payout = useMemo(()=>calcMaturity(amount, product), [amount, product])

  return (
    <div className="container py-12">
      <h1 className="text-3xl font-semibold mb-6">Festgeld-Rechner</h1>
      <div className="card p-6 space-y-4">
        <div className="grid md:grid-cols-4 gap-4">
          <Field label="Einzahlung">
            <input className="w-full border rounded-2xl px-3 py-2" type="number" min={500} step={500} value={amount} onChange={e=>setAmount(Number(e.target.value))}/>
          </Field>
          <Field label="Laufzeit">
            <select className="w-full border rounded-2xl px-3 py-2" value={term} onChange={e=>setTerm(Number(e.target.value))}>
              {PRODUCTS.map(p => <option key={p.termMonths} value={p.termMonths}>{p.termMonths} Monate</option>)}
            </select>
          </Field>
          <Field label="Zinssatz p.a.">
            <input className="w-full border rounded-2xl px-3 py-2" value={product.rate.toFixed(2)+' %'} readOnly />
          </Field>
          <Field label="Zinseszins">
            <input className="w-full border rounded-2xl px-3 py-2" value={product.compounding ? 'Ja' : 'Nein'} readOnly/>
          </Field>
        </div>
        <div className="grid md:grid-cols-3 gap-4">
          <Stat label="Auszahlung am Ende" value={payout.toLocaleString('de-DE', {style:'currency', currency:'EUR'})}/>
          <Stat label="Zinsen" value={(payout-amount).toLocaleString('de-DE', {style:'currency', currency:'EUR'})}/>
          <Stat label="Effektivzins p.a.*" value={product.rate.toFixed(2) + ' %'}/>
        </div>
        <div className="muted">* Bei linearer Verzinsung ohne Gebühren entspricht der Effektivzins dem Nominalzins.</div>
      </div>
    </div>
  )
}

function Field({label, children}:{label:string; children: React.ReactNode}){
  return <div><div className="text-sm text-gray-600 mb-1">{label}</div>{children}</div>
}
function Stat({label, value}:{label:string; value:string}){
  return <div className="bg-white rounded-2xl p-4 border shadow-sm"><div className="text-xs text-gray-500">{label}</div><div className="text-lg font-semibold">{value}</div></div>
}
