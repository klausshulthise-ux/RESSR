
import React from 'react'
export default function AGB(){
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Allgemeine Geschäftsbedingungen (Kurzfassung)</h1>
      <ul>
        <li>Kontoeröffnung setzt erfolgreiche Identitätsprüfung voraus.</li>
        <li>Festgeld ist über die Laufzeit gebunden; vorzeitige Verfügung ausgeschlossen.</li>
        <li>Zinsen werden zu den vereinbarten Terminen gutgeschrieben.</li>
      </ul>
      <p>Die vollständige Fassung erhältst du im Antragsprozess.</p>
    </div>
  )
}
