
import React from 'react'
export default function Impressum() {
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Impressum</h1>
      <p><strong>FutureYield Bank (Beispiel)</strong><br/>Musterstraße 1<br/>10115 Berlin<br/>Deutschland</p>
      <p>Telefon: 0800 000 000<br/>E-Mail: service@futureyield.example</p>
      <p>Vertreten durch den Vorstand: Max Mustermann, Erika Musterfrau</p>
      <p>Handelsregister: Amtsgericht Berlin, HRB 123456<br/>USt-IdNr.: DE123456789</p>
      <h2>Aufsichtsbehörden</h2>
      <p>Bundesanstalt für Finanzdienstleistungsaufsicht (BaFin), Deutsche Bundesbank.</p>
      <h2>Haftungsausschluss</h2>
      <p>Die Inhalte dieser Seite wurden mit größter Sorgfalt erstellt. Dennoch übernehmen wir keine Gewähr für Richtigkeit, Vollständigkeit und Aktualität.</p>
    </div>
  )
}
