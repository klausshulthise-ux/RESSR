
import React from 'react'
export default function Preise(){
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Preis- und Leistungsverzeichnis</h1>
      <table className="w-full border">
        <thead><tr className="bg-gray-100"><th className="p-2 text-left">Leistung</th><th className="p-2 text-left">Preis</th></tr></thead>
        <tbody>
          <tr><td className="p-2 border">Kontoführung Festgeld</td><td className="p-2 border">0,00 €</td></tr>
          <tr><td className="p-2 border">Identitätsprüfung (KYC)</td><td className="p-2 border">0,00 €</td></tr>
          <tr><td className="p-2 border">Kontoauszug digital</td><td className="p-2 border">0,00 €</td></tr>
        </tbody>
      </table>
      <p className="text-xs text-gray-500">Alle Preise inkl. gesetzlicher Umsatzsteuer, sofern anwendbar.</p>
    </div>
  )
}
