
import React from 'react'
export default function Datenschutz(){
  return (
    <div className="container py-12 prose prose-neutral max-w-none">
      <h1>Datenschutzhinweise</h1>
      <p>Wir verarbeiten personenbezogene Daten zur Anbahnung und Durchführung der Kontoeröffnung sowie zur Erfüllung gesetzlicher Pflichten (z. B. Geldwäschegesetz).</p>
      <h2>Verarbeitete Daten</h2>
      <ul>
        <li>Identitätsdaten (Name, Geburtsdatum, Nationalität)</li>
        <li>Kontakt- und Adressdaten</li>
        <li>Bankverbindung (IBAN des Referenzkontos)</li>
        <li>Steuer-ID</li>
        <li>Identitätsnachweise (Upload im Rahmen KYC)</li>
      </ul>
      <h2>Speicherdauer</h2>
      <p>Wir speichern Daten gemäß gesetzlicher Aufbewahrungspflichten. Nach Wegfall der Zwecke werden Daten gelöscht.</p>
      <h2>Betroffenenrechte</h2>
      <p>Dir stehen Auskunft, Berichtigung, Löschung, Einschränkung, Widerspruch sowie Datenübertragbarkeit zu.</p>
    </div>
  )
}
