
import React from 'react'
import { currentUser } from '../../utils.auth'
import { Link } from 'react-router-dom'

export default function VerifyEmail(){
  const user = currentUser()
  return (
    <div className="container py-12 max-w-xl">
      <h1 className="text-3xl font-semibold mb-6">E-Mail bestätigen</h1>
      <div className="card p-6 space-y-4">
        <p>Wir haben eine Bestätigungs-E-Mail an <strong>{user?.email}</strong> gesendet. Bitte klicke auf den Link in der E-Mail, um dein Konto zu aktivieren.</p>
        <p className="text-sm text-gray-600">Tipp: Schau auch im Spam-Ordner nach.</p>
        <Link to="/dashboard" className="btn btn-primary w-full">Zum Dashboard</Link>
      </div>
    </div>
  )
}
