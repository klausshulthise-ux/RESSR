
import React, { useState } from 'react'
import { isEmail } from '../../utils.validators'
import { login } from '../../utils.auth'
import { useNavigate, Link } from 'react-router-dom'

export default function Login(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const nav = useNavigate()
  function submit(e: React.FormEvent){
    e.preventDefault()
    if(!isEmail(email)) return setError('Bitte gültige E-Mail eingeben.')
    const user = login(email, password)
    nav(user.role === 'admin' ? '/admin' : '/dashboard')
  }
  return (
    <div className="container py-12 max-w-xl">
      <h1 className="text-3xl font-semibold mb-6">Login</h1>
      <form onSubmit={submit} className="card p-6 space-y-4">
        {error && <div className="p-3 bg-red-50 border border-red-200 rounded-2xl text-sm text-red-700">{error}</div>}
        <div>
          <div className="text-sm text-gray-600 mb-1">E-Mail</div>
          <input className="w-full border rounded-2xl px-3 py-2" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div>
          <div className="text-sm text-gray-600 mb-1">Passwort</div>
          <input type="password" className="w-full border rounded-2xl px-3 py-2" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <button className="btn btn-primary w-full">Einloggen</button>
        <div className="text-sm text-gray-600 text-center">Noch kein Konto? <Link to="/register" className="underline">Jetzt registrieren</Link></div>
      </form>
    </div>
  )
}
