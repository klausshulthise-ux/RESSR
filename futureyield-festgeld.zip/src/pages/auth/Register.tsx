
import React, { useState } from 'react'
import { isEmail } from '../../utils.validators'
import { login } from '../../utils.auth'
import { useNavigate } from 'react-router-dom'

export default function Register(){
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [agb, setAgb] = useState(false)
  const [privacy, setPrivacy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const nav = useNavigate()

  function submit(e: React.FormEvent){
    e.preventDefault()
    if(!isEmail(email)) return setError('Bitte gültige E-Mail eingeben.')
    if(!agb || !privacy) return setError('Bitte AGB und Datenschutz zustimmen.')
    login(email, password)
    nav('/verify')
  }

  return (
    <div className="container py-12 max-w-xl">
      <h1 className="text-3xl font-semibold mb-6">Konto eröffnen</h1>
      <form onSubmit={submit} className="card p-6 space-y-4">
        {error && <div className="p-3 bg-red-50 border border-red-200 rounded-2xl text-sm text-red-700">{error}</div>}
        <div>
          <div className="text-sm text-gray-600 mb-1">E-Mail</div>
          <input className="w-full border rounded-2xl px-3 py-2" value={email} onChange={e=>setEmail(e.target.value)} />
        </div>
        <div>
          <div className="text-sm text-gray-600 mb-1">Passwort</div>
          <input type="password" className="w-full border rounded-2xl px-3 py-2" value={password} onChange={e=>setPassword(e.target.value)} />
        </div>
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={agb} onChange={e=>setAgb(e.target.checked)} /> Ich akzeptiere die AGB.</label>
        <label className="flex gap-2 text-sm"><input type="checkbox" checked={privacy} onChange={e=>setPrivacy(e.target.checked)} /> Ich stimme den Datenschutzhinweisen zu.</label>
        <button className="btn btn-primary w-full">Weiter</button>
      </form>
    </div>
  )
}
