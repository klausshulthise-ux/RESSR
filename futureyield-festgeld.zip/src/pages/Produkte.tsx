
import React, { useState } from 'react'
import { PRODUCTS } from '../data.products'
import { calcMaturity } from '../utils.logic'

export default function Produkte() {
  const [amount, setAmount] = useState(10000)
  return (
    <div className="container py-12">
      <h1 className="text-3xl font-semibold mb-6">Festgeld-Produkte</h1>
      <div className="card p-6 mb-6">
        <div className="grid md:grid-cols-3 gap-4">
          <div>
            <div className="text-sm text-gray-600 mb-1">Anlagebetrag</div>
            <input className="w-full border rounded-2xl px-3 py-2" type="number" min={500} step={500} value={amount} onChange={e=>setAmount(Number(e.target.value))}/>
            <div className="muted mt-1">Passe den Betrag an, um Auszahlungen zu vergleichen.</div>
          </div>
        </div>
      </div>

      <div className="grid gap-4">
        {PRODUCTS.map(p => {
          const payout = calcMaturity(amount, p)
          return (
            <div key={p.termMonths} className="card p-4 md:p-6 flex flex-col md:flex-row md:items-center gap-4 md:gap-8">
              <div className="flex-1">
                <div className="text-lg font-semibold">{p.termMonths} Monate</div>
                <div className="text-sm text-gray-600">
                  Mindesteinlage: {p.minDeposit.toLocaleString('de-DE', {style:'currency', currency:'EUR'})} ·
                  Max: {p.maxDeposit.toLocaleString('de-DE', {style:'currency', currency:'EUR'})}
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4 w-full md:w-auto">
                <Mini label="Zinssatz p.a." value={p.rate.toFixed(2) + ' %'} />
                <Mini label="Zinseszins" value={p.compounding ? 'Ja' : 'Nein'} />
                <Mini label="Auszahlung" value={payout.toLocaleString('de-DE', {style:'currency', currency:'EUR'})} />
                <Mini label="Effektivzins*" value={p.rate.toFixed(2) + ' %'} />
                <a href="/register" className="btn btn-primary text-center">Eröffnen</a>
              </div>
            </div>
          )
        })}
      </div>
      <div className="muted mt-2">* Bei Zinszahlung am Laufzeitende ohne Gebühren entspricht der Effektivzins dem Nominalzins.</div>
    </div>
  )
}

function Mini({label, value}:{label:string; value:string}){
  return (
    <div className="bg-gray-50 rounded-2xl p-3 border">
      <div className="text-xs text-gray-500">{label}</div>
      <div className="font-medium">{value}</div>
    </div>
  )
}
