
import React from 'react'
export default function Messages(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Nachrichten</h3>
      <p>Unser Team informiert dich hier über Statusänderungen und Hinweise.</p>
    </div>
  )
}
