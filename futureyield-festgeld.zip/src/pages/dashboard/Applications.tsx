
import React from 'react'
export default function Applications(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Anträge</h3>
      <p>Deine Anträge werden hier gelistet, inklusive Status (eingereicht, KYC, genehmigt, abgelehnt). Demo: lokale Speicherung.</p>
    </div>
  )
}
