
import React from 'react'
export default function Documents(){
  return (
    <div className="prose prose-neutral max-w-none">
      <h3>Dokumente</h3>
      <p>Kontoauszüge, Vertragsdokumente und Steuerbescheinigungen erscheinen hier.</p>
    </div>
  )
}
