
import React from 'react'
import { Routes, Route, Link, NavLink } from 'react-router-dom'
import Overview from './Overview'
import Applications from './Applications'
import Documents from './Documents'
import Messages from './Messages'

export default function Dashboard(){
  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-semibold">Mein Bereich</h1>
        <Link to="/produkte" className="btn btn-primary">Neues Festgeld anlegen</Link>
      </div>
      <div className="grid md:grid-cols-4 gap-6">
        <aside className="card p-4">
          <nav className="flex flex-col gap-2 text-sm">
            <NavLink to="" end className="hover:underline">Übersicht</NavLink>
            <NavLink to="antraege" className="hover:underline">Anträge</NavLink>
            <NavLink to="dokumente" className="hover:underline">Dokumente</NavLink>
            <NavLink to="nachrichten" className="hover:underline">Nachrichten</NavLink>
          </nav>
        </aside>
        <section className="md:col-span-3">
          <div className="card p-4">
            <Routes>
              <Route index element={<Overview/>} />
              <Route path="antraege" element={<Applications/>} />
              <Route path="dokumente" element={<Documents/>} />
              <Route path="nachrichten" element={<Messages/>} />
            </Routes>
          </div>
        </section>
      </div>
    </div>
  )
}
