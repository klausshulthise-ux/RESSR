
import React from 'react'

export default function Overview(){
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-3 gap-4">
        <Card label="Gesamtanlagen" value="10.000,00 €"/>
        <Card label="Ausstehende Zinsen" value="310,00 €"/>
        <Card label="Nächste Fälligkeit" value="12.08.2026"/>
      </div>
      <div className="prose prose-neutral max-w-none">
        <h3>Willkommen zurück!</h3>
        <p>Hier findest du deine aktiven Anlagen, anstehende Fälligkeiten und neue Nachrichten. Für eine neue Anlage wechsle zu Produkte oder nutze den Button oben rechts.</p>
      </div>
    </div>
  )
}
function Card({label, value}:{label:string; value:string}){
  return <div className="bg-white border rounded-3xl p-4"><div className="text-xs text-gray-500">{label}</div><div className="text-lg font-semibold">{value}</div></div>
}
