
import React from 'react'
import { Link } from 'react-router-dom'
import { PRODUCTS } from '../data.products'
import { calcMaturity } from '../utils.logic'

export default function Home() {
  return (
    <div>
      <header className="bg-gradient-to-b from-white to-red-50">
        <div className="container py-16 grid md:grid-cols-2 gap-10">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs w-fit">Sicher & planbar</span>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">FutureYield Festgeld: feste Zinsen, klare Laufzeiten.</h1>
            <p className="text-lg text-gray-700">Lege einmal an und plane entspannt: garantierter Zinssatz über die gesamte Laufzeit. Transparente Konditionen, gesetzliche Einlagensicherung und ein Antrag, der in Minuten erledigt ist.</p>
            <div className="flex gap-3">
              <Link to="/register" className="btn btn-primary">Konto eröffnen</Link>
              <Link to="/produkte" className="btn btn-outline">Produkte ansehen</Link>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="card p-4"><div className="muted">Einlagensicherung</div><div className="font-semibold">bis 100.000 €*</div></div>
              <div className="card p-4"><div className="muted">Zinsgarantie</div><div className="font-semibold">über die Laufzeit</div></div>
              <div className="card p-4"><div className="muted">Kosten</div><div className="font-semibold">keine Kontoführungsgebühr</div></div>
            </div>
          </div>
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Beispielrechnungen</h2>
            <div className="space-y-3">
              {PRODUCTS.map(p => {
                const maturity = calcMaturity(10000, p)
                return (
                  <div key={p.termMonths} className="flex items-center justify-between border rounded-2xl p-3">
                    <div>
                      <div className="font-medium">{p.termMonths} Monate</div>
                      <div className="text-xs text-gray-500">Zins p.a. {p.rate.toFixed(2)}%</div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-gray-500">Auszahlung bei 10.000 €</div>
                      <div className="font-semibold">{maturity.toLocaleString('de-DE', { style:'currency', currency:'EUR'})}</div>
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="text-xs text-gray-500 mt-3">* Gesetzliche Einlagensicherung in der EU. Details im Abschnitt Sicherheit.</div>
          </div>
        </div>
      </header>

      <section className="container py-14 prose prose-neutral max-w-none">
        <h2>Warum Festgeld bei FutureYield?</h2>
        <p><strong>Planbarkeit:</strong> Feste Laufzeit, fester Zinssatz, klare Auszahlung. Keine versteckten Gebühren.</p>
        <p><strong>Transparenz:</strong> Effektivzins, Mindest- und Maximaleinlage, Zinszahlungstermine – alles auf einen Blick.</p>
        <p><strong>Einfacher Antrag:</strong> Von der Produktauswahl über Ident (VideoIdent/eID/PostIdent) bis zur Bestätigung.</p>
        <h3>Für wen eignet sich Festgeld?</h3>
        <ul>
          <li>Privatpersonen, die Geld für 6–36 Monate sicher parken möchten.</li>
          <li>Anleger, die auf garantierte Zinsen Wert legen.</li>
          <li>Alle, die kurzfristig keine Liquidität benötigen und eine terminierte Auszahlung bevorzugen.</li>
        </ul>
        <h3>So startest du</h3>
        <ol>
          <li>Produkt wählen und Anlagebetrag festlegen.</li>
          <li>Online-Antrag ausfüllen und Referenzkonto angeben.</li>
          <li>Identitätsprüfung abschließen.</li>
          <li>Einzahlen – fertig.</li>
        </ol>
      </section>
    </div>
  )
}
