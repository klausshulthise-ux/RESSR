
import { User } from '../types'

const KEY = 'fy_auth_user'

export function currentUser(): User | null {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null') } catch { return null }
}
export function login(email: string, password: string): User {
  const role = email === 'admin@fy.de' ? 'admin' : 'client'
  const user: User = { id: crypto.randomUUID(), email, name: email.split('@')[0], role, verified: email !== 'verify@fy.de' }
  localStorage.setItem(KEY, JSON.stringify(user))
  return user
}
export function logout(){ localStorage.removeItem(KEY) }
