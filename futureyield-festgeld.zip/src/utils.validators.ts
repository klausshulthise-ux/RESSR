
export const isEmail = (v: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)
export const isIBAN = (v: string) => /^([A-Z]{2}\d{2}[A-Z0-9]{1,30})$/.test(v.replace(/\s+/g,'').toUpperCase())
