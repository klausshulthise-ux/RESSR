
import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { Navbar } from './components/Navbar'
import { Footer } from './components/Footer'
import Home from './pages/Home'
import Produkte from './pages/Produkte'
import Rechner from './pages/Rechner'
import Sicherheit from './pages/Sicherheit'
import FAQ from './pages/FAQ'
import Impressum from './pages/recht/Impressum'
import Datenschutz from './pages/recht/Datenschutz'
import AGB from './pages/recht/AGB'
import Preise from './pages/recht/Preise'
import Login from './pages/auth/Login'
import Register from './pages/auth/Register'
import VerifyEmail from './pages/auth/VerifyEmail'
import Dashboard from './pages/dashboard/Index'
import Admin from './pages/admin/Index'
import { currentUser } from './utils.auth'

const RequireAuth: React.FC<{ role?: 'client' | 'admin', children: React.ReactNode }> = ({ role, children }) => {
  const user = currentUser()
  if (!user) return <Navigate to="/login" replace />
  if (role && user.role !== role) return <Navigate to="/" replace />
  return <>{children}</>
}

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/produkte" element={<Produkte />} />
          <Route path="/rechner" element={<Rechner />} />
          <Route path="/sicherheit" element={<Sicherheit />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/recht/impressum" element={<Impressum />} />
          <Route path="/recht/datenschutz" element={<Datenschutz />} />
          <Route path="/recht/agb" element={<AGB />} />
          <Route path="/recht/preise" element={<Preise />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/verify" element={<VerifyEmail />} />
          <Route path="/dashboard/*" element={<RequireAuth role="client"><Dashboard /></RequireAuth>} />
          <Route path="/admin/*" element={<RequireAuth role="admin"><Admin /></RequireAuth>} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
