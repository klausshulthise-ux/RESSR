
import React from 'react'
export const Logo: React.FC<{ className?: string }> = ({ className='w-8 h-8' }) => (
  <svg viewBox="0 0 64 64" className={className} aria-label="FutureYield Logo" role="img">
    <defs>
      <linearGradient id="fyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#ff445a"/>
        <stop offset="100%" stopColor="#d6001a"/>
      </linearGradient>
    </defs>
    <rect rx="14" ry="14" width="64" height="64" fill="url(#fyGrad)"/>
    <path d="M18 22h28v6H18zM18 32h18v6H18zM42 32h4c0 8-6 14-14 14H18v-6h14c4.418 0 8-3.582 8-8z" fill="#fff"/>
  </svg>
)
