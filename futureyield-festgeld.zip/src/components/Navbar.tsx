
import React from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Logo } from './Logo'
import { currentUser, logout } from '../utils.auth'

export const Navbar: React.FC = () => {
  const user = currentUser()
  return (
    <nav className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b">
      <div className="container py-3 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <Logo className="w-9 h-9" />
          <span className="font-semibold">FutureYield – Festgeld</span>
        </Link>
        <div className="hidden md:flex items-center gap-6 text-sm">
          <NavLink to="/produkte" className="hover:underline">Produkte</NavLink>
          <NavLink to="/rechner" className="hover:underline">Rechner</NavLink>
          <NavLink to="/sicherheit" className="hover:underline">Sicherheit</NavLink>
          <NavLink to="/faq" className="hover:underline">FAQ</NavLink>
          <NavLink to="/recht/impressum" className="hover:underline">Impressum</NavLink>
        </div>
        <div className="flex items-center gap-2">
          {user ? (
            <>
              <Link to={user.role === 'admin' ? '/admin' : '/dashboard'} className="btn btn-outline">Mein Bereich</Link>
              <button className="btn btn-primary" onClick={()=>{logout(); location.href='/'}}>Logout</button>
            </>
          ) : (
            <>
              <Link to="/login" className="btn btn-outline">Login</Link>
              <Link to="/register" className="btn btn-primary">Konto eröffnen</Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}
