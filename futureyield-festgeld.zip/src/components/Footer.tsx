
import React from 'react'
import { Link } from 'react-router-dom'

export const Footer: React.FC = () => (
  <footer className="py-10 border-t bg-gray-50">
    <div className="container grid md:grid-cols-4 gap-8 text-sm">
      <div>
        <div className="font-semibold mb-2">FutureYield</div>
        <p className="text-gray-600">Festgeld einfach & transparent. Keine Anlageberatung.</p>
      </div>
      <div>
        <div className="font-semibold mb-2">Rechtliches</div>
        <ul className="space-y-1 text-gray-600">
          <li><Link to="/recht/impressum" className="hover:underline">Impressum</Link></li>
          <li><Link to="/recht/datenschutz" className="hover:underline">Datenschutz</Link></li>
          <li><Link to="/recht/agb" className="hover:underline">AGB</Link></li>
          <li><Link to="/recht/preise" className="hover:underline">Preis- & Leistungsverzeichnis</Link></li>
        </ul>
      </div>
      <div>
        <div className="font-semibold mb-2">Ratgeber</div>
        <ul className="space-y-1 text-gray-600">
          <li><Link to="/ratgeber/laufzeit" className="hover:underline">Die richtige Laufzeit</Link></li>
          <li><Link to="/ratgeber/effektivzins" className="hover:underline">Effektivzins verstehen</Link></li>
          <li><Link to="/sicherheit" className="hover:underline">Einlagensicherung</Link></li>
        </ul>
      </div>
      <div>
        <div className="font-semibold mb-2">Kontakt</div>
        <div className="space-y-1 text-gray-600">
          <div>0800 000 000</div>
          <div>service@futureyield.example</div>
        </div>
      </div>
    </div>
    <div className="container mt-6 text-xs text-gray-500">© {new Date().getFullYear()} FutureYield Bank (Beispiel). Alle Rechte vorbehalten.</div>
  </footer>
)
