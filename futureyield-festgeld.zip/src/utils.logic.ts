
import { Product } from '../types'
export function calcMaturity(amount: number, p: Product){
  const years = p.termMonths / 12
  const r = p.rate / 100
  if (!p.compounding) return amount * (1 + r * years)
  const full = Math.floor(years)
  const rem = years - full
  let base = amount * Math.pow(1 + r, full)
  base *= 1 + r * rem
  return base
}
