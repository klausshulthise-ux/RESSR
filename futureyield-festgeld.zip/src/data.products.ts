
import { Product } from './types'
export const PRODUCTS: Product[] = [
  { termMonths: 6, rate: 2.8, minDeposit: 500, maxDeposit: 100000, compounding: false },
  { termMonths: 12, rate: 3.1, minDeposit: 1000, maxDeposit: 100000, compounding: false },
  { termMonths: 24, rate: 3.3, minDeposit: 1000, maxDeposit: 100000, compounding: false },
  { termMonths: 36, rate: 3.4, minDeposit: 1000, maxDeposit: 100000, compounding: true }
]
