
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#d6001a',
          50: '#ffe6ea',
          100: '#ffccd3',
          200: '#ff99a6',
          300: '#ff667a',
          400: '#ff334d',
          500: '#ff0020',
          600: '#d6001a',
          700: '#a80014',
          800: '#7a000f',
          900: '#4d0009'
        }
      }
    }
  },
  plugins: []
}
